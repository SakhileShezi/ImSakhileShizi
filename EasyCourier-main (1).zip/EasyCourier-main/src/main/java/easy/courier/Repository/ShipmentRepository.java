package easy.courier.Repository;

import easy.courier.Model.Shipping.Shipping;
import easy.courier.Model.Users.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ShipmentRepository extends JpaRepository<Shipping,Long> {

    @Query("SELECT s FROM Shipping s WHERE s.email =?1")
    List<Shipping> getShipingByUser(String email);
}
