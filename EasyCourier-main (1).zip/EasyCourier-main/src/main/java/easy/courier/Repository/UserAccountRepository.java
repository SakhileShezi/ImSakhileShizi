package easy.courier.Repository;

import easy.courier.Model.Users.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface UserAccountRepository extends JpaRepository<UserAccount,Long>
{
    UserAccount findByEmail(String email);
}
