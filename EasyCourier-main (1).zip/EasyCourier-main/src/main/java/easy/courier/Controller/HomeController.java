package easy.courier.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController
{

    @GetMapping("/")
    public String showAdminDashboard(Model model) {
        return "home"; // Name of the Thymeleaf template
    }

    @GetMapping("/login")
    public String login(Model model){
        return "login";
    }


    @GetMapping("/register")
    public String registerUser(Model model) {
        return "registration";
    }
}
