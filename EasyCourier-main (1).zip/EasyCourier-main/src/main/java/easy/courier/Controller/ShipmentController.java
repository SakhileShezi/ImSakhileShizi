package easy.courier.Controller;

import easy.courier.Model.Shipping.Shipping;
import easy.courier.Model.Shipping.Status;
import easy.courier.Model.Users.UserAccount;
import easy.courier.Repository.ShipmentRepository;
import easy.courier.Repository.UserAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;

@Controller
public class ShipmentController
{

    @Autowired
    private UserAccountRepository userRepository;

    @Autowired
    private ShipmentRepository shipmentRepository;

    @GetMapping("/shipment/{id}")
    public String createShipment(Model model, @PathVariable String id)
    {
       // String username = principal.getName();
        UserAccount user = userRepository.findByEmail(id);
        model.addAttribute("shipment", new Shipping());
        model.addAttribute("userAccount", user);
        return "shipment";
    }

    @PostMapping("/createShipment/{email}")
    public String createShipment(@ModelAttribute("shipment") Shipping shipment, @PathVariable String email) {

        UserAccount user = userRepository.findByEmail(email);
        shipment.setEmail(email);
        shipment.setStatus(Status.CREATED);
        shipmentRepository.save(shipment);
        return "redirect:/welcome/"+email;
    }

    @PostMapping("/shipment/delete/{id}")
    public String deleteShipment(@PathVariable("id") Long shipmentId) {
        // Call the service method to delete the shipment

       Shipping shipping= shipmentRepository.findById(shipmentId).orElse(null);
       if(shipping==null){
           return "redirect:/home";
       }

        shipmentRepository.deleteById(shipmentId);
        // Redirect back to the dashboard
        return "redirect:/welcome/"+shipping.getEmail();
    }


}
