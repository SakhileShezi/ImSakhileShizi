package easy.courier.Controller;

import easy.courier.Model.Users.UserAccount;
import easy.courier.Service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserAccountController
{

    @Autowired
    private  UserAccountService userRepository;

    @GetMapping("/profile")
    public String showProfile(Model model) {
        // Fetch user details (you can get the logged-in user from the session)
        return "profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute UserAccount updatedUser) {
        // Update user details in the repository
       // userRepository.save(updatedUser);
        return "redirect:/profile";
    }


}
