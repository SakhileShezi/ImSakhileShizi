package easy.courier.Controller;


import easy.courier.Model.Shipping.Shipping;
import easy.courier.Model.Users.Login;
import easy.courier.Model.Users.UserAccount;
import easy.courier.Repository.ShipmentRepository;
import easy.courier.Repository.UserAccountRepository;
import easy.courier.Service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller

public class RegistrationController
{



    @Autowired
    private  UserAccountService userAccountService;

    @Autowired
    private ShipmentRepository shipmentRepository;
    @Autowired
    private UserAccountRepository userRepository;



    @PostMapping("/register")
    public String register(UserAccount userAccount) {
        System.out.println("Linda");
        userAccountService.register(userAccount);
        System.out.println("Linda");
        return "redirect:/login";
    }

    @PostMapping("/login")
    public String login(UserAccount userAccount, Model model){

        System.out.println("Login "+userAccount.toString());
        System.out.println(userAccountService.login(userAccount));
        if(userAccountService.login(userAccount)){
            List<Shipping> shipments = shipmentRepository.getShipingByUser(userAccount.getEmail());
            // Add the list of shipments to the model
            System.out.println(shipments.size()+" ----");
            if(shipments.size()>0){

                model.addAttribute("shipments", shipments);
            }

            return "redirect:/welcome/"+userAccount.getEmail();
            //return "welcome";
        }else{
            model.addAttribute("errorMessage", "Invalid credentials. Please register if you're a new user.");
            return "login";
        }

    }

    @GetMapping("welcome/{email}")
    public String welcome(Model model, @PathVariable String email){

        UserAccount user = userRepository.findByEmail(email);
        model.addAttribute("userAccount", user);
        List<Shipping> shipments = shipmentRepository.getShipingByUser(email);
        // Add the list of shipments to the model
        System.out.println(shipments.size()+" ----");
        if(shipments.size()>0){

            model.addAttribute("shipments", shipments);
        }

        return "welcome";
    }

}
