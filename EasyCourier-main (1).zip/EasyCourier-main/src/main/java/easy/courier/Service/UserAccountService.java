package easy.courier.Service;

import easy.courier.Model.Users.Login;
import easy.courier.Model.Users.UserAccount;
import easy.courier.Repository.UserAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserAccountService
{

    @Autowired
    private UserAccountRepository userAccountRepository;



    public void register(UserAccount userAccount) {
        userAccountRepository.save(userAccount);
    }

    public boolean login(UserAccount login)
    {
        UserAccount userAccount = userAccountRepository.findByEmail(login.getEmail());

        if(userAccount!=null){
            return userAccount.getPassword().equals(login.getPassword());
        }
        return false;
    }

    public Optional<UserAccount> findById(long id)
    {
        return Optional.of(userAccountRepository.getReferenceById(id));
    }
}
