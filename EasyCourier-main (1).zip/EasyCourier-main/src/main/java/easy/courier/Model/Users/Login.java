package easy.courier.Model.Users;

public class Login
{
    public String email;
    public String password;

    @Override
    public String toString() {
        return "Login{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
