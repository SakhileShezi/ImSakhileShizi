package easy.courier.Model.Shipping;

public enum Status
{
    COMPLETE,
    CANCELED,
    CREATED,
    DRIVER_ACCEPT,
    DRIVER_TO_PICK_UP,
    DRIVER_TO_DROP_OFF;
}
